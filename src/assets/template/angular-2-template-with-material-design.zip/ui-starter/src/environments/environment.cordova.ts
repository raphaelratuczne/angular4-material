export const environment = {
  production: true,
  cordova: true,
  electron: false
};
