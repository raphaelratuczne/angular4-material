export const environment = {
  production: true,
  cordova: false,
  electron: false
};
