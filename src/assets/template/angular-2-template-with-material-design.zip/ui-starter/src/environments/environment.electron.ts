export const environment = {
  production: true,
  cordova: false,
  electron: true
};
